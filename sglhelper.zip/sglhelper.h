#pragma once

#include <iostream>
#include <array>

void testFunction();

