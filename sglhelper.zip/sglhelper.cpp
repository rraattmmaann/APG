#include "sglhelper.h"

void testFunction() {
	std::cout << "test\n";
}